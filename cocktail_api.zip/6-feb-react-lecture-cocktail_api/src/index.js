import React from 'react'
import ReactDOM from 'react-dom'
import App from './App'

let htmlElement = document.getElementById('root')

let root = ReactDOM.createRoot(htmlElement)

root.render(<App />)